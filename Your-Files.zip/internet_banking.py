import json
import os
import datetime

DATA_FILE = "/content/user_data.json"

# Utility Functions
def load_data():
    if not os.path.exists(DATA_FILE):
        return {}
    with open(DATA_FILE, "r") as file:
        return json.load(file)

def save_data(data):
    with open(DATA_FILE, "w") as file:
        json.dump(data, file, indent=4)

# Banking Logic
def register_user(username, password):
    data = load_data()
    if username in data:
        return False, "User already exists."
    data[username] = {
        "password": password,
        "balance": 0.0,
        "transactions": []
    }
    save_data(data)
    return True, "Registration successful."

def login_user(username, password):
    data = load_data()
    if username in data and data[username]["password"] == password:
        return True
    return False

def deposit_amount(username, amount):
    data = load_data()
    data[username]["balance"] += amount
    data[username]["transactions"].append(f"[{datetime.datetime.now()}] Deposited ₹{amount}")
    save_data(data)

def withdraw_amount(username, amount):
    data = load_data()
    if data[username]["balance"] >= amount:
        data[username]["balance"] -= amount
        data[username]["transactions"].append(f"[{datetime.datetime.now()}] Withdrew ₹{amount}")
        save_data(data)
        return True, "Withdrawal successful."
    return False, "Insufficient balance."

def transfer_amount(sender, receiver, amount):
    data = load_data()
    if receiver not in data:
        return False, "Receiver does not exist."
    if data[sender]["balance"] < amount:
        return False, "Insufficient balance."

    data[sender]["balance"] -= amount
    data[receiver]["balance"] += amount

    data[sender]["transactions"].append(f"[{datetime.datetime.now()}] Transferred ₹{amount} to {receiver}")
    data[receiver]["transactions"].append(f"[{datetime.datetime.now()}] Received ₹{amount} from {sender}")

    save_data(data)
    return True, "Transfer successful."

def get_balance(username):
    data = load_data()
    return data[username]["balance"]

def get_transaction_history(username):
    data = load_data()
    return data[username]["transactions"]

# CLI Menu
def main():
    print("="*40)
    print("    🏦 Internet Banking System")
    print("="*40)

    while True:
        print("\n1. Register")
        print("2. Login")
        print("3. Exit")

        choice = input("Enter your choice: ").strip()

        if choice == "1":
            username = input("Choose a username: ").strip()
            password = input("Choose a password: ").strip()
            success, message = register_user(username, password)
            print(message)

        elif choice == "2":
            username = input("Enter username: ").strip()
            password = input("Enter password: ").strip()

            if login_user(username, password):
                print(f"✅ Login successful! Welcome, {username}")
                while True:
                    print("\n--- Banking Menu ---")
                    print("1. Deposit")
                    print("2. Withdraw")
                    print("3. Transfer")
                    print("4. Check Balance")
                    print("5. Transaction History")
                    print("6. Logout")

                    option = input("Choose an option: ").strip()

                    if option == "1":
                        amount = float(input("Enter amount to deposit: ₹"))
                        deposit_amount(username, amount)
                        print("✅ Deposit successful.")

                    elif option == "2":
                        amount = float(input("Enter amount to withdraw: ₹"))
                        success, message = withdraw_amount(username, amount)
                        print("✅" if success else "❌", message)

                    elif option == "3":
                        to_user = input("Enter recipient username: ").strip()
                        amount = float(input("Enter amount to transfer: ₹"))
                        success, message = transfer_amount(username, to_user, amount)
                        print("✅" if success else "❌", message)

                    elif option == "4":
                        balance = get_balance(username)
                        print(f"💰 Current balance: ₹{balance:.2f}")

                    elif option == "5":
                        history = get_transaction_history(username)
                        print("\n📄 Transaction History:")
                        if history:
                            for tx in history:
                                print("  -", tx)
                        else:
                            print("  No transactions yet.")

                    elif option == "6":
                        print("👋 Logged out.")
                        break

                    else:
                        print("❌ Invalid option. Try again.")

            else:
                print("❌ Invalid username or password.")

        elif choice == "3":
            print("Thank you for banking with us. 🏦")
            break

        else:
            print("❌ Invalid choice. Please try again.")

# Run the app
main()
